javac -d . -cp .:jna.jar ../../../Source/MediaInfoDLL/MediaInfoDLL.JNA.java ../../../Source/Example/HowToUse_Dll.java
